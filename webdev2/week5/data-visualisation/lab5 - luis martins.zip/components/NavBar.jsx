const NavBar = () => (
    <div>
        <ul>
            <li>Sales Data</li>
            <li>Earnings Data</li>
        </ul>
    </div>
)
export default NavBar