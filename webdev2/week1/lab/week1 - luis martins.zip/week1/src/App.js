import './App.css';
import Movies from './components/Movies';

function App() {
  return (
    <div className="App">
      <Movies/ >
    </div>
  );
}

export default App;
