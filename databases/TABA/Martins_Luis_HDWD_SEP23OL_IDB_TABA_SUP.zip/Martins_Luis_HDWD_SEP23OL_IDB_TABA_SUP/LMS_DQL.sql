-- Select all from Author
SELECT * FROM Author;

-- Select all from ISBN
SELECT * FROM ISBN;

-- Select all from Publisher
SELECT * FROM Publisher;

-- Select all from Address
SELECT * FROM Address;

-- Select all from MemberType
SELECT * FROM MemberType;

-- Select all from Book
SELECT * FROM Book;

-- Select all from BookAuthor
SELECT * FROM BookAuthor;

-- Select all from Member
SELECT * FROM Member;

-- Select all from Loan
SELECT * FROM Loan;