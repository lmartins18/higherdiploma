public class Newspaper {

	private String id;
	private String title;
	private Date publicationDate;
	private Double price;
	private String language;
	private String publisher;
	private String content;
	private Integer quantity;

	public String getTitle() {
		return this.title;
	}

	/**
	 * 
	 * @param newTitle
	 */
	public void setTitle(String newTitle) {
		this.title = newTitle;
	}

	public Date getPublicationDate() {
		return this.publicationDate;
	}

	/**
	 * 
	 * @param newDate
	 */
	public void setPublicationDate(Date newDate) {
		this.publicationDate = newDate;
	}

	public double getPrice() {
		// TODO - implement Newspaper.getPrice
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param newPrice
	 */
	public void setPrice(double newPrice) {
		// TODO - implement Newspaper.setPrice
		throw new UnsupportedOperationException();
	}

	public String getLanguage() {
		return this.language;
	}

	/**
	 * 
	 * @param newLanguage
	 */
	public void setLanguage(String newLanguage) {
		this.language = newLanguage;
	}

	public String getPublisher() {
		return this.publisher;
	}

	/**
	 * 
	 * @param newPublisher
	 */
	public void setPublisher(String newPublisher) {
		this.publisher = newPublisher;
	}

	public String getContent() {
		return this.content;
	}

	/**
	 * 
	 * @param newContent
	 */
	public void setContent(String newContent) {
		this.content = newContent;
	}

	/**
	 * 
	 * @param quantity
	 */
	public void setQuantity(integer quantity) {
		// TODO - implement Newspaper.setQuantity
		throw new UnsupportedOperationException();
	}

	public integer getQuantity() {
		// TODO - implement Newspaper.getQuantity
		throw new UnsupportedOperationException();
	}

	public void operation() {
		// TODO - implement Newspaper.operation
		throw new UnsupportedOperationException();
	}

}