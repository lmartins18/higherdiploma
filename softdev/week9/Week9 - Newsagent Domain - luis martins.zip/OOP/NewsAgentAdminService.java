public class NewsAgentAdminService {

	/**
	 * 
	 * @param newspaperId
	 */
	public void viewNewspaper(integer newspaperId) {
		// TODO - implement NewsAgentAdminService.viewNewspaper
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param newNewspaper
	 */
	public void addNewspaper(Newspaper newNewspaper) {
		// TODO - implement NewsAgentAdminService.addNewspaper
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param newspaperId
	 */
	public void removeNewspaper(integer newspaperId) {
		// TODO - implement NewsAgentAdminService.removeNewspaper
		throw new UnsupportedOperationException();
	}

	public void manageSales() {
		// TODO - implement NewsAgentAdminService.manageSales
		throw new UnsupportedOperationException();
	}

	public void inventoryManagement() {
		// TODO - implement NewsAgentAdminService.inventoryManagement
		throw new UnsupportedOperationException();
	}

	public void customerManagement() {
		// TODO - implement NewsAgentAdminService.customerManagement
		throw new UnsupportedOperationException();
	}

}