public class TransactionService {

	private ShoppingCart shoppingCart;
	private integer attemptLimit = 3;
	private integer attemptsMade;

	public void cancelTransaction() {
		// TODO - implement TransactionService.cancelTransaction
		throw new UnsupportedOperationException();
	}

	public void blockTransaction() {
		// TODO - implement TransactionService.blockTransaction
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param paymentType
	 */
	public void processTransaction(PaymentType paymentType) {
		// TODO - implement TransactionService.processTransaction
		throw new UnsupportedOperationException();
	}

	public void handlePayment() {
		// TODO - implement TransactionService.handlePayment
		throw new UnsupportedOperationException();
	}

}