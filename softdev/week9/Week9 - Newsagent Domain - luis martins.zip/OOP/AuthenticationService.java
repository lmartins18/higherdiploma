public class AuthenticationService {

	/**
	 * 
	 * @param username
	 * @param password
	 */
	public boolean login(String username, String password) {
		// TODO - implement AuthenticationService.login
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 * @param password
	 */
	public void createAccount(String username, String password) {
		// TODO - implement AuthenticationService.createAccount
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 * @param password
	 */
	private boolean verifyPassword(String username, String password) {
		// TODO - implement AuthenticationService.verifyPassword
		throw new UnsupportedOperationException();
	}

	private void displayWrongDetails() {
		// TODO - implement AuthenticationService.displayWrongDetails
		throw new UnsupportedOperationException();
	}

}