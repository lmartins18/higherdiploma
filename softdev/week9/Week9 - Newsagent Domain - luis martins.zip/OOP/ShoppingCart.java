public class ShoppingCart {

	private Newspaper[] shoppingCart;
	public Transaction transaction;

	public Newspaper[] getShoppingCart() {
		return this.shoppingCart;
	}

	/**
	 * 
	 * @param newspaper
	 */
	public void addToShoppingCart(Newspaper newspaper) {
		// TODO - implement ShoppingCart.addToShoppingCart
		throw new UnsupportedOperationException();
	}

}