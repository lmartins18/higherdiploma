package Lab2;

//class definition
public class MyFristProgram{
	//main method header
	public static void Main(String[] args){
		System.out.println("I love Maths");
		System.out.println("And I love java too");

	}
}