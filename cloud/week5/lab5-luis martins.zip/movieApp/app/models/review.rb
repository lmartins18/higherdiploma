class Review < ApplicationRecord
  belongs_to :movie
end
